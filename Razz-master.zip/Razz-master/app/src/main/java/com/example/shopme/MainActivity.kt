package com.example.shopme

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

// here are all of the import files

class MainActivity : AppCompatActivity() {

    private lateinit var listingAdapter: ShopAdapter
//main activity contains all of the files nesisary to give the code function
    //all code allows for adding and deleting to the list view
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listingAdapter = ShopAdapter(mutableListOf())
        //section for all of the listing for the app, makes the items list
        shopItems.adapter = listingAdapter
        shopItems.layoutManager = LinearLayoutManager(this)

        btnAdd.setOnClickListener {
            val shopsTitle = shopTitle.text.toString()
            if(shopsTitle.isNotEmpty()) {
                val item = Item(shopsTitle)
                listingAdapter.addShop(item)
                shopTitle.text.clear()
            }
        //this section adds the item that the user types in
        //this code gives purpose to the add button at the bottom of the screen
            //allowing for them to add shopping items to the list
        }
        btnDelete.setOnClickListener {
            listingAdapter.deleteDoneItems()

            //this section of the code is the functionality for deleting items
            //this can be see by the name delete done items therefore deleting the items that have been found
            //
        }
    }
}

// comment

