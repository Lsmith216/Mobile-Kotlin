package com.example.shopme

data class Item(
    val title: String,
    var isChecked: Boolean = false
)