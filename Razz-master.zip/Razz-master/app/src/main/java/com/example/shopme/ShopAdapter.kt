package com.example.shopme

import android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_listv.view.*
//shop adapter class is the class that contains all of the logic and the functionality
//allowing for the app to function
class ShopAdapter(
    private val items: MutableList<Item>
) : RecyclerView.Adapter<ShopAdapter.shopViewHolder>() {

    class shopViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): shopViewHolder {
        return shopViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_listv,
                parent,
                false
            )
        //layout xml file above being referenced
        )
    }
    //functionality for allowing the items to be added to the list
    fun addShop(item: Item) {
        items.add(item)
        notifyItemInserted(items.size - 1)
    }
//functionality for allowing the items to be deleted from the list
    //goes through items on list if the items on the list are checked
    //they will be deleted if button is pressed

    fun deleteDoneItems() {
        items.removeAll { prod ->
            prod.isChecked
        }
        notifyDataSetChanged()
    }

    private fun toggleStrikeThrough(ListTitle: TextView, isChecked: Boolean) {
        if(isChecked) {
            ListTitle.paintFlags = ListTitle.paintFlags or STRIKE_THRU_TEXT_FLAG
        } else {
            ListTitle.paintFlags = ListTitle.paintFlags and STRIKE_THRU_TEXT_FLAG.inv()
        }
        //puts a strike through the text once it has been clicked
        //to indicate that an item has been clicked or found
    }

    override fun onBindViewHolder(holder: shopViewHolder, position: Int) {
        val curlists = items[position]
        holder.itemView.apply {
            ListTitle.text = curlists.title
            cbDone.isChecked = curlists.isChecked
            toggleStrikeThrough(ListTitle, curlists.isChecked)
            cbDone.setOnCheckedChangeListener { _, isChecked ->
                toggleStrikeThrough(ListTitle, isChecked)
                curlists.isChecked = !curlists.isChecked
            }
            //functionality to check the check box
            //for showing that an item has been ticked and found
            //both the tick box and strike line for showing an items ticked off the shopping list
        }
    }

    override fun getItemCount(): Int {
        return items.size
        //shows the app how many items it needs to be displaying
    }
}


















